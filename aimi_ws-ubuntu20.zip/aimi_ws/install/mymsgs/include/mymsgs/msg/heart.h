// generated from rosidl_generator_c/resource/idl.h.em
// with input from mymsgs:msg/Heart.idl
// generated code does not contain a copyright notice

#ifndef MYMSGS__MSG__HEART_H_
#define MYMSGS__MSG__HEART_H_

#include "mymsgs/msg/detail/heart__struct.h"
#include "mymsgs/msg/detail/heart__functions.h"
#include "mymsgs/msg/detail/heart__type_support.h"

#endif  // MYMSGS__MSG__HEART_H_
