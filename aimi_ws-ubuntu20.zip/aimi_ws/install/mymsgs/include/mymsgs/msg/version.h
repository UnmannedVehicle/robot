// generated from rosidl_generator_c/resource/idl.h.em
// with input from mymsgs:msg/Version.idl
// generated code does not contain a copyright notice

#ifndef MYMSGS__MSG__VERSION_H_
#define MYMSGS__MSG__VERSION_H_

#include "mymsgs/msg/detail/version__struct.h"
#include "mymsgs/msg/detail/version__functions.h"
#include "mymsgs/msg/detail/version__type_support.h"

#endif  // MYMSGS__MSG__VERSION_H_
