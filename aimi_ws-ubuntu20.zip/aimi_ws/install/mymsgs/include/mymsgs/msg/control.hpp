// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef MYMSGS__MSG__CONTROL_HPP_
#define MYMSGS__MSG__CONTROL_HPP_

#include "mymsgs/msg/detail/control__struct.hpp"
#include "mymsgs/msg/detail/control__builder.hpp"
#include "mymsgs/msg/detail/control__traits.hpp"

#endif  // MYMSGS__MSG__CONTROL_HPP_
