// generated from rosidl_generator_c/resource/idl.h.em
// with input from mymsgs:msg/Attitued.idl
// generated code does not contain a copyright notice

#ifndef MYMSGS__MSG__ATTITUED_H_
#define MYMSGS__MSG__ATTITUED_H_

#include "mymsgs/msg/detail/attitued__struct.h"
#include "mymsgs/msg/detail/attitued__functions.h"
#include "mymsgs/msg/detail/attitued__type_support.h"

#endif  // MYMSGS__MSG__ATTITUED_H_
