// generated from rosidl_generator_c/resource/idl.h.em
// with input from mymsgs:msg/Core.idl
// generated code does not contain a copyright notice

#ifndef MYMSGS__MSG__CORE_H_
#define MYMSGS__MSG__CORE_H_

#include "mymsgs/msg/detail/core__struct.h"
#include "mymsgs/msg/detail/core__functions.h"
#include "mymsgs/msg/detail/core__type_support.h"

#endif  // MYMSGS__MSG__CORE_H_
